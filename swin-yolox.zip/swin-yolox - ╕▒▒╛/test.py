from PIL import Image

img = Image.open("D:/project/yolox-swin-t/img/FLIR_00001.jpeg")
img2 = Image.open("D:/project/yolox-swin-t/img_out/FLIR_00001.jpeg")
img3 = Image.open('D:/project/yolox-swin-t/1/12_street_second_3.jpg')
print(img.mode)
print(img2.mode)
print(img3.mode)
